# About Fluent Bit

[Fluent Bit](http://fluentbit.io) is an open source and multi-platform data collection tool which aims to be a generic Swiss knife for events collection on IoT environments and related hardware devices.

We, [Treasure Data](http://treasuredata.com), as a Big Data company, provide an analytics infrastructure in the Cloud where we provide an end-to-end solution to collect, store and do analytics over the data. [Fluent Bit](http://fluentbit.io) is an integral part of this pipeline where it solve the data collection needs where the __source__ information may come from Embedded and IoT environments.
