# Getting Started

[Fluent Bit](http://fluentbit.io) is a very straightforward tool, despites it still on it early development stage, it provide some useful plugins and built-in features (most of them only available for Linux based systems).

The following documentation cover the instructions for the __v0.1__ version, if you find some problem on a certain step, don't hesitate to report the problem on our bug tracker:

https://github.com/fluent/fluent-bit/issues
